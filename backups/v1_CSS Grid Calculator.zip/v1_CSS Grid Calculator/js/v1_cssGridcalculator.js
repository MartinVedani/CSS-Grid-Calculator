/*  Tutorial videos: https://www.youtube.com/watch?v=LHKu6oDyZwg&feature=youtu.be 
                    https://www.youtube.com/watch?v=LNGNJa0bCV8&feature=youtu.be */

const app = new Vue({
    el: '#app',

    data: {
        numbers: [{ name: 'zeroo', value: 0 }, { name: 'one', value: 1 }, { name: 'two', value: 2 }, { name: 'three', value: 3 }, { name: 'four', value: 4 }, { name: 'five', value: 5 }, { name: 'six', value: 6 }, { name: 'seven', value: 7 }, { name: 'eight', value: 8 }, { name: 'nine', value: 9 }, { name: 'float', value: '.' }],

        /* el nombre de zeroo lo q tengo q escribir con dos "o" porque zero con 1 sola 0 es una variable reservada de css */

        ops: [{ name: 'plus', value: '+' }, { name: 'minus', value: '-' }, { name: 'by', value: '*' }, { name: 'divided', value: '/' }],

        actions: [{ name: 'equal', value: '=' }, { name: 'clear', value: 'C' }, { name: 'backspace', value: '<<' }, { name: 'sqrt', value: '√' }, { name: 'power', value: '^2' }],

        output: []
    },

    methods: {
        print(key) {
            if (this.output.includes('SyntaxError')) {
                this.output = []
            }
            this.output.push(key.value)
                /* agrega el valor de la tecla donde se hizo click en al array output */
        },

        handleFunction(function_name) {
            return this[function_name]()
        },

        clear() {
            this.output = []
        },

        backspace() {
            if (this.output.includes('SyntaxError')) {
                this.output = []
            }
            this.output.pop()
        },

        equal() {
            try {
                this.output = [eval(this.output.join(''))]
            } catch (error) {
                this.output = [error.name]
            }
        },

        sqrt() {
            try {
                this.output = [Math.sqrt(this.output.join(''))]
            } catch (error) {
                this.output = [error.name]
            }
        },

        power() {
            try {
                this.output = [Math.pow(this.output.join(''), 2)]
            } catch (error) {
                this.output = [error.name]
            }
        }
    },

    computed: {
        fancyOutput() {
            return this.output.map(e => this.ops.some(op => e == op.value) || e == 'SyntaxError' ? `<span style="color:red"> ${e} </span>` : e)
        }
    }
});